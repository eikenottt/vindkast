const wish_list = [53, 995, 1130, 1133],
    loan_list = [2685, 1100, 620];

