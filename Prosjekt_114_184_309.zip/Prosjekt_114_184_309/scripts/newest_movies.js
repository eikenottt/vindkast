window.onload = function () {
    loadRecOnIndex();
}


